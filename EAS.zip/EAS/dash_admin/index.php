<?php include "header.php"; ?>
<?php include "menu.php"; ?>
<div class="wrapper">
	<?php include "home.php"; ?>
<?php include "footer.php"; ?>
